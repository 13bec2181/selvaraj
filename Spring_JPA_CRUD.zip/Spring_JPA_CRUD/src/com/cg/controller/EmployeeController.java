package com.cg.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.entities.Employee;
import com.cg.service.EmployeeService;
@Controller
public class EmployeeController {

	@Autowired 
	EmployeeService employeeService;
	
	@RequestMapping("index")
	public String toToAddEmployee(Model model)
	{
		Employee emp = new Employee();
		model.addAttribute("emp", emp);
		return "addEmp";
		
	}
	@RequestMapping("addEmp")
	public String addEmployee(@Valid @ModelAttribute("emp")Employee emp,BindingResult result,Model model)
	{
		Employee bean = null;
		String page = null;
		if(result.hasErrors())
		{System.out.println("error");
			page = "addEmp";
		}
		else
		{
			employeeService.addEmployee(emp);
			
			model.addAttribute("bean",emp);
			
			page="success";
			
		}
		return page;
	}
	@RequestMapping("search")
	public String search(Model model)
	{
		Employee emp = new Employee();
		System.out.println("inside search");
		model.addAttribute("emp", emp);
		return "searchById";
			
	}
	
	@RequestMapping("searchById")
	public String searchById(@Valid @ModelAttribute("emp")Employee emp,BindingResult result,Model model)
	{
		Employee bean = null;
		String page = null;
		System.out.println(emp.getEmployeeId());
		if(result.hasErrors())
		{System.out.println("error");
			page = "searchById";
		}
		else
		{
			Employee emp1=employeeService.searchById(emp.getEmployeeId());
			model.addAttribute("bean",emp1);
			page="display";
	
		}
		return page;
	}
	@RequestMapping("update")
	public String update(Model model)
	{
		Employee emp = new Employee();
		model.addAttribute("emp", emp);
		return "updateIdForm";
		
		
	}
	//@RequestParam("id")int id, @RequestParam("name")int name, @RequestParam("salary")int salary
	@RequestMapping("updateEmp")
	public String updateEmp(@Valid  @ModelAttribute("emp")Employee emp,BindingResult result,Model model)
	{
		Employee bean = null;
		String page = null;
		
		if(result.hasErrors())
		{System.out.println("error");
			page = "updateIdForm";
		}
		else
		{
			Employee emp1=employeeService.searchById(emp.getEmployeeId());
			model.addAttribute("emp",emp1);
			page="update";
		}
		return page;

	}
	@RequestMapping("updated")
	public String updated(@Valid  @RequestParam("id")int id, @RequestParam("name")String name, @RequestParam("salary")int salary,Model model)
	{
		Employee bean = null;
		String page = null;
		
		/*if(result.hasErrors())
		{System.out.println("error");
			page = "updated";
		}*/
		/*else
		{*/
			Employee emp1= new Employee();
			emp1.setEmployeeId(new Long(id));
			emp1.setEmpName(name);
			emp1.setEmpSal(salary);
			employeeService.update(emp1);
			model.addAttribute("bean",emp1);
			page="display";
		//}
		return page;
		}
	@RequestMapping("delete")
	public String delete(Model model)
	{
		Employee emp = new Employee();
		model.addAttribute("emp", emp);
		return "deleteForm";
		
}
	@RequestMapping("deleted")
	public String deletedEmp(@Valid  @ModelAttribute("emp")Employee emp,BindingResult result,Model model)
	{
		Employee bean = null;
		String page = null;
		
		if(result.hasErrors())
		{System.out.println("error");
			page = "deleteForm";
		}
		else
		{
			employeeService.delete(emp.getEmpName());
			model.addAttribute("emp",emp);
			page="deleteEmp";
		}
		return page;
	}
}
