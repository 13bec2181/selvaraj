package com.cg.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.EmployeeDao;
import com.cg.entities.Employee;

@Service
@Transactional
public class EmployeeServiceImpl implements EmployeeService{

	@Autowired
	EmployeeDao employeeDao;
	@Override
	public void addEmployee(Employee emp) {
		// TODO Auto-generated method stub
		employeeDao.addEmployee(emp);
	}
	@Override
	public List<Employee> getEmployee(int id) {
		// TODO Auto-generated method stub
		return employeeDao.getEmployee(id);
	}
	@Override
	public Employee searchById(Long employeeId) {
		// TODO Auto-generated method stub
		return employeeDao.searchById(employeeId);
	}
	@Override
	public void update(Employee emp1) {
		// TODO Auto-generated method stub
		 employeeDao.update(emp1);
	}
	@Override
	public void delete(String empName) {
		// TODO Auto-generated method stub
		employeeDao.delete(empName);
	}

}
