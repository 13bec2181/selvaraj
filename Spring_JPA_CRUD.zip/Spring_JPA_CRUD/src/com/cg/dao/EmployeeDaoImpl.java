package com.cg.dao;


import java.util.List;

import javax.persistence.EntityManager;
//import javax.persistence.PersistenceContext;

import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.entities.Employee;

@Repository
public class EmployeeDaoImpl implements EmployeeDao{

	@PersistenceContext
	EntityManager em;
	
	
	@Override
	public void addEmployee(Employee emp) {
		// TODO Auto-generated method stub
		//em.getTransaction().begin();
		em.persist(emp);
		em.flush();
		//em.getTransaction().commit();
			
	}


	@Override
	public List<Employee> getEmployee(int id) {
		// TODO Auto-generated method stub
		Long idl = new Long(id);
		String sql="Select p from Employee p";
		TypedQuery<Employee> t = em.createQuery(sql, Employee.class);
		System.out.println("in");
		List<Employee> e = t.getResultList();
		for(Employee e1:e)
		System.out.println(e1.getEmpName());
		return e;
	}


	@Override
	public Employee searchById(Long employeeId) {
		// TODO Auto-generated method stub
		String sql="Select p from Employee p where p.employeeId=:id";
		
		TypedQuery<Employee> t = em.createQuery(sql, Employee.class);
		t.setParameter("id",employeeId);
		Employee e=t.getSingleResult();
		return e;
	}


	@Override
	@Transactional
	public void update(Employee emp1) {
		// TODO Auto-generated method stub
		em.merge(emp1);
	}


	@Override
	@Transactional
	public void delete(String empName) {
		// TODO Auto-generated method stub
String sql="Delete from Employee p where p.empName=:name";
		
		Query t = em.createQuery(sql);
		t.setParameter("name",empName);
		int r = t.executeUpdate();
		
		System.out.println("deleted"+r);
	}

}
