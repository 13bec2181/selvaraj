package com.cg.dao;

import java.util.List;

import com.cg.entities.Employee;

public interface EmployeeDao {

	public void addEmployee(Employee emp);

	public List<Employee> getEmployee(int id);

	public Employee searchById(Long employeeId);

	public void update(Employee emp1);

	public void delete(String empName);
}
