

package com.cg.trainee.dao;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.trainee.dto.Login;
import com.cg.trainee.dto.Trainee;

@Repository("loginDao")
@Transactional
public class LoginDaoImpl implements ILoginDao{
	
	@PersistenceContext
	private EntityManager entityManager;
	
	public EntityManager getEntityManager() {
		return entityManager;
	}

	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	@Override
	public boolean isUserExist(String loguser) {
		// TODO Auto-generated method stub
		Login log = entityManager.find(Login.class, loguser);
		System.out.println("In login dao ....."+log);
		boolean flag = false;
		if(log!= null)
		{
			flag=true;
		}
		return flag;
	}

	@Override
	public boolean isValid(Login log) {
		// TODO Auto-generated method stub
		Login lg = entityManager.find(Login.class, log.getUsername());
		boolean flag=false;
		if(log.getPassword().equalsIgnoreCase(lg.getPassword()))
		{
			flag= true;
		}
		
		return flag;
	}

	@Override
	public Trainee addingTrainee(Trainee addTrainee) {
		// TODO Auto-generated method stub
		System.out.println("adding in DAO");
		entityManager.persist(addTrainee);
		//entityManager.flush();
		System.out.println("Added in DAO");
		return addTrainee;
		
	}

	@Override
	public ArrayList<Trainee> getAllTrainees() {
		String QRY= "SELECT details FROM Trainee details";
		TypedQuery<Trainee> tq= 
				entityManager.createQuery(QRY,
						Trainee.class);
		ArrayList<Trainee> traineeL=
				(ArrayList)tq.getResultList();
		System.out.println(traineeL);
		return traineeL;
	}

	@Override
	public Trainee updateTrainee(int traineeId, String traineeName, String traineeLocation,
			String traineeDomain) {
		
		Trainee updt = entityManager.find(Trainee.class, traineeId);
		System.out.println(updt);
		updt.setTraineeName(traineeName);
		updt.setTraineeLocation(traineeLocation);
		updt.setTraineeDomain(traineeDomain);
		Trainee updt1 = entityManager.merge(updt);
		System.out.println(updt1);
		return updt1;
	}

}
