package com.cg.trainee.ctrl;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cg.trainee.dto.Login;
import com.cg.trainee.service.ILoginService;

@Controller
//@RequestMapping("logCtrl")
public class LoginController {
	
	@Autowired
	ILoginService loginuser;

	public ILoginService getLoginuser() {
		return loginuser;
	}

	public void setLoginuser(ILoginService loginuser) {
		this.loginuser = loginuser;
	}
	

	@RequestMapping(value = "/ShowLoginPage", method = RequestMethod.GET)
	public String dispIndexPage(Model model) {
		Login lg = new Login();
		model.addAttribute("loginUser", lg);
		return "Login";
	}
	
	@RequestMapping(value="/validateUser", method = RequestMethod.POST)
	public String isValidate(@Valid
			@ModelAttribute("loginUser") Login lgg,
			BindingResult result, Model model)
			{
				String username="admin";
				String password="admin";
				
				
				if(username.equalsIgnoreCase(lgg.getUsername()) && password.equalsIgnoreCase(lgg.getPassword()))
				{
					return "TraineeManagement";
				}
				else
				{
					return "error";
				}
			}
}
