package com.cg.trainee.ctrl;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.trainee.dto.Trainee;
import com.cg.trainee.service.ILoginService;

@Controller
public class TraineeController {

	@Autowired
	ILoginService loginser;
	ArrayList<String> domainlist = null;

	public ILoginService getLoginser() {
		return loginser;
	}

	public void setLoginser(ILoginService loginser) {
		this.loginser = loginser;
	}

	@RequestMapping(value="/addTrainee",method=RequestMethod.GET)
	public String addingTrainee(Model model)
	{
		domainlist  = new ArrayList<String>();
		domainlist.add("java");
		domainlist.add("oracle");
		domainlist.add("c");
		domainlist.add("c++");

		Trainee details = new Trainee();
		model.addAttribute("addedTrainee", details);
		model.addAttribute("domain", domainlist);
		return "AddingTrainee";
	}
	@RequestMapping(value="/dispAddTrainee",method=RequestMethod.GET)
	public String traineeAdded(@ModelAttribute("addedTrainee") Trainee details,BindingResult result,Model model)
	{

		loginser.addingTrainee(details);

		return "TraineeAdded";
	}
	
	@RequestMapping(value="/menu", method=RequestMethod.GET)
	public String menuTrainee()
	{
		return "TraineeManagement";
	}
		
	@RequestMapping(value="/getAllTrainee",method=RequestMethod.GET)
	public String dispTrainees(Model model)
	{
		ArrayList<Trainee> usrl=
				loginser.getAllTrainees();
				model.addAttribute("dispTrainee", usrl);
		return "ListTrainees";
	}
	
	@RequestMapping(value="/modifyTrainee", method=RequestMethod.GET)
	public String updtTrainee(Model model)
	{
		return "Modifytrainee";
	}
	
	@RequestMapping(value="/updateTrainee", method=RequestMethod.GET)
	public String modifyTrainee(@RequestParam(value="traineeId") Model model)
	{
		return "modifiedTrainee";
	}
	@RequestMapping(value="/updatedTrainee", method=RequestMethod.GET)
	public String updatedTrainee()
	{
		int traineeId = 0;
		String traineeName = null;
		String traineeLocation = null;
		String traineeDomain = null;
		Trainee tr= loginser.updateTrainee(traineeId, traineeName, traineeLocation, traineeDomain);
		
		return "modifiedSuccess";
	}
}
