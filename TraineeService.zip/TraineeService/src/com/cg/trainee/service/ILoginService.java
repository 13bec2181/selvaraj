package com.cg.trainee.service;

import java.util.ArrayList;

import com.cg.trainee.dto.Login;
import com.cg.trainee.dto.Trainee;

public interface ILoginService {
	public boolean isUserExist(String loguser);
	public boolean isValid(Login log);
	public Trainee addingTrainee(Trainee addTrainee);
	public ArrayList<Trainee> getAllTrainees();
	public Trainee updateTrainee(int traineeId,String traineeName, String traineeLocation, String traineeDomain);

}
