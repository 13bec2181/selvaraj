
package com.cg.trainee.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.trainee.dao.ILoginDao;
import com.cg.trainee.dto.Login;
import com.cg.trainee.dto.Trainee;

@Service("loginser")
public class LoginServiceImpl implements ILoginService {
	
	@Autowired
	ILoginDao logindao;


	public ILoginDao getLogindao() {
		return logindao;
	}

	public void setLogindao(ILoginDao logindao) {
		this.logindao = logindao;
	}

	@Override
	public boolean isUserExist(String loguser) {
		// TODO Auto-generated method stub
		return logindao.isUserExist(loguser);
	}

	@Override
	public boolean isValid(Login log) {
		// TODO Auto-generated method stub
		return logindao.isValid(log);
	}

	@Override
	public Trainee addingTrainee(Trainee addTrainee) {
		// TODO Auto-generated method stub
		return logindao.addingTrainee(addTrainee);
	}

	@Override
	public ArrayList<Trainee> getAllTrainees() {
		// TODO Auto-generated method stub
		return logindao.getAllTrainees();
	}

	@Override
	public Trainee updateTrainee(int traineeId, String traineeName, String traineeLocation,
			String traineeDomain) {
		// TODO Auto-generated method stub
		return logindao.updateTrainee(traineeId, traineeName, traineeLocation, traineeDomain);
	}
	

}
