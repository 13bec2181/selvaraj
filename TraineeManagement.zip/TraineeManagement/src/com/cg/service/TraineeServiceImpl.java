package com.cg.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.Trainee;
import com.cg.dto.TraineeDto;
@Service("traineeSer")
public class TraineeServiceImpl implements TraineeService {

@Autowired
Trainee traineeDao;
	


public Trainee getTraineeDao() {
	return traineeDao;
}



public void setTraineeDao(Trainee traineeDao) {
	this.traineeDao = traineeDao;
}



@Override
	public TraineeDto addTrainee(TraineeDto trainee) {
		// TODO Auto-generated method stub
		return traineeDao.addTrainee(trainee);
	}



@Override
public ArrayList<TraineeDto> getAllUsers() {
	// TODO Auto-generated method stub
return traineeDao.getAllUsers();
}



@Override
public TraineeDto getTrainee(String traineeId) {
	// TODO Auto-generated method stub
	return traineeDao.getTrainee(traineeId);
}



@Override
public TraineeDto deleteTrainee(String traineeId) {
	// TODO Auto-generated method stub
	return traineeDao.deleteTrainee(traineeId);
}



@Override
public TraineeDto updateTrainee(TraineeDto trainee) {
	// TODO Auto-generated method stub
	return traineeDao.updateTrainee(trainee);
}

	
}
