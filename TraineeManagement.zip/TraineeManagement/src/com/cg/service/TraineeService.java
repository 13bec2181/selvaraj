package com.cg.service;

import java.util.ArrayList;

import com.cg.dto.TraineeDto;

public interface TraineeService {

	public TraineeDto addTrainee(TraineeDto trainee);
	public ArrayList<TraineeDto> getAllUsers();
	public TraineeDto getTrainee(String traineeId);
	public TraineeDto deleteTrainee(String traineeId);
	public TraineeDto updateTrainee(TraineeDto trainee);
}
