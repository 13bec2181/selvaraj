package com.cg.dao;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;






import com.cg.dto.TraineeDto;
@Repository("traineeDao")
@Transactional
public class TraineeDaoImpl implements Trainee
{
@PersistenceContext
private EntityManager entitymanager;

	public EntityManager getEntitymanager() {
	return entitymanager;
}

public void setEntitymanager(EntityManager entitymanager) {
	this.entitymanager = entitymanager;
}

	@Override
	public TraineeDto addTrainee(TraineeDto trainee) {
		entitymanager.persist(trainee);
		entitymanager.flush();
		System.out.println(trainee);
		System.out.println("nuvvu ante naku chala istam da");
		return trainee;
	}

	@Override
	public ArrayList<TraineeDto> getAllUsers() {
		String qry="SELECT tra FROM TraineeDto tra";
		TypedQuery<TraineeDto> tq=entitymanager.createQuery(qry, TraineeDto.class);
		ArrayList<TraineeDto> userL=(ArrayList)tq.getResultList();
		return userL;
	}

	@Override
	public TraineeDto getTrainee(String traineeId) {
		TraineeDto user=entitymanager.find(TraineeDto.class, traineeId);
		
		return user;
	}

	@Override
	public TraineeDto deleteTrainee(String traineeId) {
		TraineeDto user=entitymanager.find(TraineeDto.class, traineeId);
		entitymanager.remove(user);
		return user;
	}

	@Override
	public TraineeDto updateTrainee(TraineeDto trainee) {
	
		TraineeDto user=entitymanager.find(TraineeDto.class,trainee.getTraineeId());
	System.out.println(user);
	String domain=trainee.getDomain();
	user.setDomain(domain);
	String location=trainee.getLocation();
	user.setLocation(location);
	String name=trainee.getTraineeName();
	user.setTraineeName(name);
	TraineeDto usr1=entitymanager.merge(user);
	return usr1;
	
	}

}	

