package com.cg.dao;

import java.util.ArrayList;




import com.cg.dto.TraineeDto;

public interface Trainee

{
public TraineeDto addTrainee(TraineeDto trainee);
public ArrayList<TraineeDto> getAllUsers();
public TraineeDto getTrainee(String traineeId);
public TraineeDto deleteTrainee(String traineeId);
public TraineeDto updateTrainee(TraineeDto trainee);
}
