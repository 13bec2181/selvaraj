package com.cg.controller;

import java.util.ArrayList;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.dto.Login;

import com.cg.dto.TraineeDto;
import com.cg.service.TraineeService;

@Controller

public class TraineeController {
@Autowired
TraineeService traineeSer;

	public TraineeService getTraineeSer() {
	return traineeSer;
}
public void setTraineeSer(TraineeService traineeSer) {
	this.traineeSer = traineeSer;
}
	@RequestMapping(value="/ShowloginPage",method=RequestMethod.GET)
	public String dispIndexPage(Model model)
	{
		Login usr=new Login();
		model.addAttribute("loginUser",usr);
	return "login";
	}
	@RequestMapping(value = "/validateUser", method = RequestMethod.GET)
	public String validateLogin(
			@Valid
			@ModelAttribute("loginUser") Login usr,
			BindingResult result, Model model) 
	{
		if (result.hasErrors()) 
		{
			
			return "error";
		} 
		else 
		{
			String un = "admin";
			String pw = "admin";
		if(un.equalsIgnoreCase( usr.getUserName() )&&(pw.equalsIgnoreCase(usr.getPwd())))
		{
			return "success";
		}
		else{
			return "login";
		}
		}
			
	}
	@RequestMapping(value="/addTraineeDetails",method=RequestMethod.
			GET)
	public String addTraineeDetails(Model model){
		
		TraineeDto t1=new TraineeDto();
		model.addAttribute("trainee", t1);
		
		return "add";
		
	}
	@RequestMapping(value="/addtrainee",method=RequestMethod.
			GET)
	public String addTrainee(@ModelAttribute("trainee") TraineeDto usr,Model model)
	{
		traineeSer.addTrainee(usr);
		return "added";
	}
	@RequestMapping(value="/Retrievealltrainees",method=RequestMethod.GET)
	public String retrieveAll(Model model){
		ArrayList<TraineeDto> usr=traineeSer.getAllUsers();
model.addAttribute("UserListObj",usr);
		return "ListAllUsers";
	}
	@RequestMapping(value="/DeleteTrainee",method=RequestMethod.GET)
	public String findTrainee(Model model)
	{
	TraineeDto trainee=new TraineeDto();
	model.addAttribute("details",trainee);
	return "find";
	}
	@RequestMapping(value="/deletetrainee",method=RequestMethod.GET)
	public String deleteTrainee(Model model,@ModelAttribute("details")TraineeDto usr)
	{	
		String traineeId=usr.getTraineeId();
		usr=traineeSer.getTrainee(traineeId);
		model.addAttribute("details",usr);
	return "findall";
		
	}
	@RequestMapping(value="/deleted", method=RequestMethod.GET)
	public String deleted(Model model,@RequestParam("tid") String traineeId)
	{
		traineeSer.deleteTrainee(traineeId);
		return "success";
		}
	@RequestMapping(value="/findTrainee",method=RequestMethod.GET)
	public String findTrainees(Model model)
	{
	TraineeDto trainee=new TraineeDto();
	model.addAttribute("details",trainee);
	return "retrieve";
	}
	@RequestMapping(value="/retrievetrainee",method=RequestMethod.GET)
	public String getTrainee(Model model,@ModelAttribute("details")TraineeDto usr)
	{	
		String traineeId=usr.getTraineeId();
		usr=traineeSer.getTrainee(traineeId);
		model.addAttribute("details",usr);
	return "getall";
		
	}

	@RequestMapping(value="/modifytrainee",method=RequestMethod.GET)
	public String modifyTrainee(Model model)
	{
		return "modify";
	}
	
	@RequestMapping(value="/modifyTrainee",method=RequestMethod.GET)
	public String modifiedTrainee(@RequestParam(value="id") String id,Model model)
	{
		TraineeDto tr1=traineeSer.getTrainee(id);
		
		String id1=tr1.getTraineeId();
		String name=tr1.getTraineeName();
		String location=tr1.getLocation();
		String domain=tr1.getDomain();
		
		TraineeDto te1=new TraineeDto();
		model.addAttribute("modify", te1);
		model.addAttribute("id1", id1);
		model.addAttribute("name", name);
		model.addAttribute("location", location);
		model.addAttribute("domain", domain);
		
		return "modified";
		
	}
	
	@RequestMapping(value="/modified",method=RequestMethod.GET)
	public String modifyDetails(@ModelAttribute(value="modify") TraineeDto tr5,Model model)
	{
			
		traineeSer.updateTrainee(tr5);
		
		return "success";
		
	}
	
}
