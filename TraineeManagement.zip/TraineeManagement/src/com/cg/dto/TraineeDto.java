package com.cg.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="trainee")
public class TraineeDto {
	
	
	@Column(name="traineename")
	private String traineeName;
	
	
	
	@Id
	@Column(name="traineeid")
	private String traineeId;
	@Column(name="domain")
	private String domain;
	@Column(name="location")
	private String location;
	
	
	public String getTraineeName() {
		return traineeName;
	}
	public void setTraineeName(String traineeName) {
		this.traineeName = traineeName;
	}
	public String getTraineeId() {
		return traineeId;
	}
	public void setTraineeId(String traineeId) {
		this.traineeId = traineeId;
	}
	public String getDomain() {
		return domain;
	}
	public void setDomain(String domain) {
		this.domain = domain;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	@Override
	public String toString() {
		return "TraineeDto [traineeName=" + traineeName + ", traineeId="
				+ traineeId + ", domain=" + domain + ", location=" + location
				+ "]";
	}
	public TraineeDto() {
		super();
		// TODO Auto-generated constructor stub
	}
	public TraineeDto(String traineeName, String traineeId, String domain,
			String location) {
		super();
		this.traineeName = traineeName;
		this.traineeId = traineeId;
		this.domain = domain;
		this.location = location;
	}
	
	
	
	
}
